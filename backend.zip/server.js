const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const mysql = require('mysql2/promise');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Root route for testing
app.get('/', (req, res) => {
  res.send('✅ Zomato Backend is running');
});

// MySQL connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT || 10),
  connectTimeout: parseInt(process.env.DB_TIMEOUT || 60000)
});

// Create DB and tables if not exists
async function initDatabase() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD
  });

  await connection.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME}\``);
  await connection.end();

  const poolConn = await pool.getConnection();

  await poolConn.query(`
    CREATE TABLE IF NOT EXISTS menu_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255),
      description TEXT,
      price DECIMAL(10,2),
      category VARCHAR(100),
      isVeg BOOLEAN,
      isAvailable BOOLEAN,
      nutritionalInfo TEXT,
      gstRate DECIMAL(5,2),
      servingInfo TEXT
    )
  `);

  await poolConn.query(`
    CREATE TABLE IF NOT EXISTS categories (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255),
      description TEXT,
      isActive BOOLEAN
    )
  `);

  await poolConn.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      customerName VARCHAR(255),
      customerPhone VARCHAR(15),
      totalAmount DECIMAL(10,2),
      status VARCHAR(50),
      orderTime DATETIME,
      estimatedTime VARCHAR(100),
      paymentMethod VARCHAR(100),
      deliveryAddress TEXT,
      specialInstructions TEXT,
      noCutlery BOOLEAN
    )
  `);

  await poolConn.query(`
    CREATE TABLE IF NOT EXISTS outlet_settings (
      id INT PRIMARY KEY,
      outletName VARCHAR(255),
      contactNumber VARCHAR(20),
      address TEXT,
      isOpen BOOLEAN
    )
  `);
  await poolConn.query(`
    CREATE TABLE IF NOT EXISTS restaurants (
      restaurant_id INT PRIMARY KEY AUTO_INCREMENT,
      restaurant_name VARCHAR(255) NOT NULL,
      cuisine_type VARCHAR(100),
      address TEXT,
      image_url TEXT,
      rating DECIMAL(3,1),
      minimum_order_value DECIMAL(10,2)
    )
  `);

  await poolConn.release();
}

// --- All your existing API routes here (unchanged) ---

// Menu Management
app.get('/api/menu', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM menu_items');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/menu', async (req, res) => {
  try {
    const {
      name, description, price, category, isVeg, isAvailable,
      nutritionalInfo, gstRate, servingInfo
    } = req.body;

    const [result] = await pool.query(
      `INSERT INTO menu_items 
        (name, description, price, category, isVeg, isAvailable, nutritionalInfo, gstRate, servingInfo) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [name, description, price, category, isVeg, isAvailable, nutritionalInfo, gstRate, servingInfo]
    );

    const [newItem] = await pool.query('SELECT * FROM menu_items WHERE id = ?', [result.insertId]);
    res.status(201).json(newItem[0]);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/menu/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const fields = req.body;
    const keys = Object.keys(fields);
    const values = Object.values(fields);
    const setClause = keys.map(key => `${key} = ?`).join(', ');
    await pool.query(`UPDATE menu_items SET ${setClause} WHERE id = ?`, [...values, id]);
    const [updated] = await pool.query('SELECT * FROM menu_items WHERE id = ?', [id]);
    res.json(updated[0]);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/menu/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM menu_items WHERE id = ?', [id]);
    res.json({ message: 'Item deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Category Management
app.get('/api/categories', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categories');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/categories', async (req, res) => {
  try {
    const { name, description, isActive } = req.body;
    const [result] = await pool.query(
      'INSERT INTO categories (name, description, isActive) VALUES (?, ?, ?)',
      [name, description, isActive]
    );
    const [newCategory] = await pool.query('SELECT * FROM categories WHERE id = ?', [result.insertId]);
    res.status(201).json(newCategory[0]);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/categories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const fields = req.body;
    const keys = Object.keys(fields);
    const values = Object.values(fields);
    const setClause = keys.map(key => `${key} = ?`).join(', ');
    await pool.query(`UPDATE categories SET ${setClause} WHERE id = ?`, [...values, id]);
    const [updated] = await pool.query('SELECT * FROM categories WHERE id = ?', [id]);
    res.json(updated[0]);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/categories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM categories WHERE id = ?', [id]);
    res.json({ message: 'Category deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Order Management
app.get('/api/orders', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM orders');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const {
      customerName, customerPhone, totalAmount, status,
      estimatedTime, paymentMethod, deliveryAddress,
      specialInstructions, noCutlery
    } = req.body;

    const orderTime = new Date().toISOString();
    const [result] = await pool.query(
      `INSERT INTO orders 
        (customerName, customerPhone, totalAmount, status, orderTime, estimatedTime, paymentMethod, deliveryAddress, specialInstructions, noCutlery) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        customerName, customerPhone, totalAmount, status || 'new', orderTime,
        estimatedTime, paymentMethod, deliveryAddress, specialInstructions, noCutlery
      ]
    );

    const [newOrder] = await pool.query('SELECT * FROM orders WHERE id = ?', [result.insertId]);
    res.status(201).json(newOrder[0]);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const fields = req.body;
    const keys = Object.keys(fields);
    const values = Object.values(fields);
    const setClause = keys.map(key => `${key} = ?`).join(', ');
    await pool.query(`UPDATE orders SET ${setClause} WHERE id = ?`, [...values, id]);
    const [updated] = await pool.query('SELECT * FROM orders WHERE id = ?', [id]);
    res.json(updated[0]);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Outlet Settings
app.get('/api/outlet', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM outlet_settings LIMIT 1');
    res.json(rows[0] || {});
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/outlet', async (req, res) => {
  try {
    const data = req.body;
    const keys = Object.keys(data);
    const values = Object.values(data);
    const setClause = keys.map(key => `${key} = ?`).join(', ');
    await pool.query(`UPDATE outlet_settings SET ${setClause} WHERE id = 1`, [...values]);
    const [updated] = await pool.query('SELECT * FROM outlet_settings WHERE id = 1');
    res.json(updated[0]);
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Restaurant Management
app.get('/api/restaurants', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM restaurants');
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('Error fetching restaurants:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch restaurants' });
  }
});

app.get('/api/restaurants/:restaurantId/menu', async (req, res) => {
  const { restaurantId } = req.params;

  try {
    const [rows] = await pool.query(
      'SELECT * FROM menu_items WHERE restaurant_id = ?',
      [restaurantId]
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('Error fetching menu items:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch menu items' });
  }
});


// Start server after DB initialized
initDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`✅ Server running at http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("❌ Failed to initialize DB:", err);
  });
