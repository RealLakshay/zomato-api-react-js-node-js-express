# MySQL Workbench 8.0 CE Setup Guide

This guide will help you set up the Zomato Management System with MySQL Workbench 8.0 CE.

## 🔧 Prerequisites

1. **MySQL Workbench 8.0 CE** installed and running
2. **MySQL Server** running on localhost:3306
3. **Root user** with password "root"

## 🚀 Quick Setup

### Step 1: Verify MySQL Workbench Connection

1. Open **MySQL Workbench 8.0 CE**
2. Create a new connection with these settings:
   - **Connection Name**: Zomato Local
   - **Hostname**: localhost
   - **Port**: 3306
   - **Username**: root
   - **Password**: root
3. Test the connection to ensure it works

### Step 2: Setup Project

\`\`\`bash
# Navigate to backend folder
cd backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env
# The .env file is already configured for root/root

# Test database connection
npm run test:connection

# Setup database for Workbench
npm run setup:workbench

# Start the server
npm start
\`\`\`

## 🔍 Verification Steps

### 1. Test Connection
\`\`\`bash
npm run test:connection
\`\`\`
This will verify:
- ✅ MySQL server connectivity
- ✅ Authentication with root/root
- ✅ Database and table existence
- ✅ Sample data verification

### 2. Check in MySQL Workbench
1. Open MySQL Workbench 8.0 CE
2. Connect to your local server
3. Look for `zomato_management` database
4. Verify these tables exist:
   - customers
   - restaurants  
   - menu_categories
   - menu_items
   - orders
   - order_items
   - restaurant_hours
   - customer_addresses
   - reviews

### 3. Test API Endpoints
\`\`\`bash
# Start the server
npm start

# Test in browser or Postman:
# http://localhost:5000/api/restaurants
# http://localhost:5000/api/menu
# http://localhost:5000/api/orders
\`\`\`

## 🛠️ Troubleshooting

### Connection Issues

**Error: Access Denied**
\`\`\`bash
# Check MySQL user privileges
# In MySQL Workbench, run:
SELECT user, host FROM mysql.user WHERE user = 'root';
SHOW GRANTS FOR 'root'@'localhost';
\`\`\`

**Error: Connection Refused**
\`\`\`bash
# Check if MySQL service is running
# Windows: Services → MySQL80
# Mac: System Preferences → MySQL
# Linux: sudo systemctl status mysql
\`\`\`

**Error: Database Not Found**
\`\`\`bash
# Reset and recreate database
npm run db:reset
npm run setup:workbench
\`\`\`

### Common Solutions

1. **Reset Root Password**:
   \`\`\`sql
   ALTER USER 'root'@'localhost' IDENTIFIED BY 'root';
   FLUSH PRIVILEGES;
   \`\`\`

2. **Grant Permissions**:
   \`\`\`sql
   GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost';
   FLUSH PRIVILEGES;
   \`\`\`

3. **Check Port**:
   \`\`\`sql
   SHOW VARIABLES LIKE 'port';
   \`\`\`

## 📊 Database Schema Overview

### Core Tables
- **restaurants** (4 sample restaurants)
- **customers** (4 sample customers)  
- **menu_items** (30+ food items)
- **orders** (3 sample orders)

### Relationships
- Restaurants → Menu Categories → Menu Items
- Customers → Orders → Order Items
- Restaurants ← → Operating Hours

## 🔐 Security Notes

- Default credentials (root/root) are for development only
- Change credentials for production use
- Enable SSL for production databases
- Use environment variables for sensitive data

## 📱 Integration with Frontend

Once the database is set up:

1. **Start Backend**: `npm start` (runs on port 5000)
2. **Start Frontend**: Navigate to frontend folder and start React app
3. **Test Integration**: Create orders, manage menu, etc.

## 🆘 Getting Help

If you encounter issues:

1. **Check Logs**: Server logs show detailed error messages
2. **Test Connection**: Use `npm run test:connection`
3. **Verify Workbench**: Ensure you can connect manually
4. **Reset Database**: Use `npm run db:reset` for fresh start

## 📋 Useful MySQL Workbench Queries

\`\`\`sql
-- Check database size
SELECT 
    table_schema AS 'Database',
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)'
FROM information_schema.tables 
WHERE table_schema = 'zomato_management';

-- View all orders with customer details
SELECT 
    o.order_number,
    c.customer_name,
    r.restaurant_name,
    o.order_status,
    o.total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN restaurants r ON o.restaurant_id = r.restaurant_id;

-- Check menu items by restaurant
SELECT 
    r.restaurant_name,
    mc.category_name,
    mi.item_name,
    mi.price,
    mi.is_available
FROM restaurants r
JOIN menu_categories mc ON r.restaurant_id = mc.restaurant_id
JOIN menu_items mi ON mc.category_id = mi.category_id
ORDER BY r.restaurant_name, mc.category_name;
